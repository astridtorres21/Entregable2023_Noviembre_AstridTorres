import "./Card.css";

//Este componente deberia recibir por props y mostrar en pantalla la informacion
//que envia el usuario

function Card(props) {
    return (
    <div className="card">
        {props.children}
    </div>
    );
}

export default Card;