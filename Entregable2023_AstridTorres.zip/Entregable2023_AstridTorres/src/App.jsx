import "./App.css";
import Formulario from "./components/Formulario";

function App() {

  //Aqui deberias agregar los estados y los handlers para los inputs

  return (
    <div className="App">
      <h1>Ingresa los datos de tu mascota</h1>
      <Formulario/>
    </div>
  );
}

export default App;
